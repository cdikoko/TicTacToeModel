package edu.jsu.mcis;

public class TicTacToe {





	public static void main(String[] args) {
		TicTacToeModel model = new TicTacToeModel();
		
	}
}
